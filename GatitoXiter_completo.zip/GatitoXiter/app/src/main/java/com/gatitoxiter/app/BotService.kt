package com.gatitoxiter.app

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class BotService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, "gatito_ch")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("😺 Gatito Xiter")
            .setContentText("Rodando em segundo plano 🐾")
            .setOngoing(true)
            .build()
        startForeground(2, notification)
        return START_STICKY
    }
}
