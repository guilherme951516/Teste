package com.gatitoxiter.app

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var stateIdle: LinearLayout
    private lateinit var stateLoading: LinearLayout
    private lateinit var stateCaptcha: LinearLayout
    private lateinit var stateDone: LinearLayout
    private lateinit var statusDot: View
    private lateinit var tvBannerStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvTimer: TextView
    private lateinit var tvLoadingMsg: TextView
    private lateinit var tvStepCount: TextView
    private lateinit var tvKey: TextView
    private lateinit var tvKeyExpiry: TextView
    private lateinit var tvHistory: TextView
    private lateinit var webView: WebView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnHistory: Button
    private lateinit var btnCopy: Button
    private lateinit var dots: List<View>

    // Estado
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var stepCount = 0
    private val maxSteps = 8
    private var elapsedSeconds = 0
    private var timerRunnable: Runnable? = null
    private var adClickCount = 0
    private val MAX_AD_CLICKS = 3

    private val TARGET_URL = "https://submais.paginadariqueza.com/submais/?vsl=Uua3JAYPg25&i=1&t=63417743910271742296&utm_source=634_submais"
    private val PREFS_KEY = "gatito_history"

    private val loadingMessages = listOf(
        "Carregando encurtador... 🐾",
        "Aguardando timer... ⏳",
        "Captcha detectado → resolva! 🛡️",
        "Anúncio clicado → aguardando... ↩️",
        "Liberando acesso... ⏳",
        "Clicando em Continuar... 🐾",
        "Processando próxima etapa... ⚙️",
        "Capturando chave King_Cheats_... 🔑",
        "Quase lá... 😼"
    )

    private val dotColors = listOf(
        0xFFFF4FA3.toInt(), 0xFFB44FFF.toInt(), 0xFF00CCFF.toInt(),
        0xFFFF4FA3.toInt(), 0xFFB44FFF.toInt(), 0xFF00CCFF.toInt(),
        0xFFFF4FA3.toInt(), 0xFFB44FFF.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        setContentView(R.layout.activity_main)
        bindViews()
        createNotificationChannel()
        checkBatteryOptimization()
        setupWebView()
        setupButtons()
        showState("idle")
        loadHistory()
    }

    private fun bindViews() {
        stateIdle = findViewById(R.id.stateIdle)
        stateLoading = findViewById(R.id.stateLoading)
        stateCaptcha = findViewById(R.id.stateCaptcha)
        stateDone = findViewById(R.id.stateDone)
        statusDot = findViewById(R.id.statusDot)
        tvBannerStatus = findViewById(R.id.tvBannerStatus)
        progressBar = findViewById(R.id.progressBar)
        tvTimer = findViewById(R.id.tvTimer)
        tvLoadingMsg = findViewById(R.id.tvLoadingMsg)
        tvStepCount = findViewById(R.id.tvStepCount)
        tvKey = findViewById(R.id.tvKey)
        tvKeyExpiry = findViewById(R.id.tvKeyExpiry)
        tvHistory = findViewById(R.id.tvHistory)
        webView = findViewById(R.id.webView)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnHistory = findViewById(R.id.btnHistory)
        btnCopy = findViewById(R.id.btnCopy)
        dots = listOf(
            findViewById(R.id.dot1), findViewById(R.id.dot2),
            findViewById(R.id.dot3), findViewById(R.id.dot4),
            findViewById(R.id.dot5), findViewById(R.id.dot6),
            findViewById(R.id.dot7), findViewById(R.id.dot8)
        )
    }

    // ─── ESTADOS DA UI ────────────────────────────────────────────────────────

    private fun showState(state: String) {
        stateIdle.visibility = if (state == "idle") View.VISIBLE else View.GONE
        stateLoading.visibility = if (state == "loading") View.VISIBLE else View.GONE
        stateCaptcha.visibility = if (state == "captcha") View.VISIBLE else View.GONE
        stateDone.visibility = if (state == "done") View.VISIBLE else View.GONE

        when (state) {
            "idle" -> {
                statusDot.setBackgroundColor(0xFF333333.toInt())
                tvBannerStatus.text = "AGUARDANDO"
                tvBannerStatus.setTextColor(0xFF664477.toInt())
            }
            "loading" -> {
                statusDot.setBackgroundColor(0xFFFF4FA3.toInt())
                tvBannerStatus.text = "BUSCANDO..."
                tvBannerStatus.setTextColor(0xFFFF4FA3.toInt())
            }
            "captcha" -> {
                statusDot.setBackgroundColor(0xFFFFAA00.toInt())
                tvBannerStatus.text = "VERIFICANDO"
                tvBannerStatus.setTextColor(0xFFFFAA00.toInt())
            }
            "done" -> {
                statusDot.setBackgroundColor(0xFF00FF88.toInt())
                tvBannerStatus.text = "CONCLUÍDO 🐾"
                tvBannerStatus.setTextColor(0xFF00FF88.toInt())
            }
        }
    }

    private fun updateDots(activeCount: Int) {
        dots.forEachIndexed { i, dot ->
            if (i < activeCount) {
                dot.setBackgroundColor(dotColors[i])
            } else {
                dot.setBackgroundColor(0xFF333333.toInt())
            }
        }
        tvStepCount.text = "${minOf(activeCount, maxSteps)}/$maxSteps etapas 🐾"
    }

    // ─── TIMER ────────────────────────────────────────────────────────────────

    private fun startTimer() {
        elapsedSeconds = 0
        timerRunnable = object : Runnable {
            override fun run() {
                elapsedSeconds++
                tvTimer.text = "⏱ ${elapsedSeconds}s"
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(timerRunnable!!)
    }

    private fun stopTimer() {
        timerRunnable?.let { handler.removeCallbacks(it) }
    }

    // ─── BATTERY ──────────────────────────────────────────────────────────────

    private fun checkBatteryOptimization() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val manufacturer = Build.MANUFACTURER.lowercase()
            val msg = when {
                manufacturer.contains("xiaomi") || manufacturer.contains("redmi") ->
                    "Para funcionar em 2° plano no seu Xiaomi:\n\nConfigurações → Bateria → Economia de energia → App → Sem restrições"
                manufacturer.contains("samsung") ->
                    "Para funcionar em 2° plano:\n\nConfigurações → Bateria → Otimização de bateria → GatitoXiter → Não otimizar"
                else -> "Desative a otimização de bateria para funcionar em segundo plano."
            }
            AlertDialog.Builder(this)
                .setTitle("😺⚡ Permissão Necessária")
                .setMessage(msg)
                .setPositiveButton("🐾 Permitir") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:$packageName")
                        })
                    } catch (e: Exception) {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
                .setNegativeButton("Depois", null)
                .show()
        }
    }

    // ─── NOTIFICAÇÃO ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("gatito_ch", "Gatito Xiter", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showNotification(msg: String) {
        val intent = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "gatito_ch")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("😺 Gatito Xiter Key")
            .setContentText(msg)
            .setContentIntent(intent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    private fun cancelNotification() {
        getSystemService(NotificationManager::class.java).cancel(1)
    }

    // ─── WEBVIEW ──────────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.userAgentString = "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    // Interceptar apps externos e redirecionar para web
                    if (url.startsWith("intent://") || url.startsWith("instagram://") ||
                        url.startsWith("tg://") || url.startsWith("whatsapp://")) {
                        val webUrl = when {
                            url.startsWith("instagram://") -> "https://www.instagram.com/"
                            url.startsWith("tg://") -> "https://t.me/"
                            else -> "https://www.google.com"
                        }
                        view.loadUrl(webUrl)
                        handler.postDelayed({ if (view.canGoBack()) view.goBack() }, 1500)
                        return true
                    }
                    return false
                }

                override fun onPageFinished(view: WebView, url: String) {
                    if (!isRunning) return
                    // Atualiza progresso
                    progressBar.progress = 100
                    handler.postDelayed({ progressBar.progress = 0 }, 500)
                    checkForKey(view)
                    handler.postDelayed({ runBot(view) }, 2500)
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, p: Int) {
                    progressBar.progress = p
                }
            }

            addJavascriptInterface(JsInterface(), "GatitoAndroid")
        }
    }

    // ─── BOT ──────────────────────────────────────────────────────────────────

    private fun runBot(view: WebView) {
        if (!isRunning) return

        val js = """
        (function() {
            var body = document.body;
            if (!body) return 'no_body';
            var texto = body.innerText || '';

            // 1. Chave encontrada?
            var match = texto.match(/King_Cheats_[A-Za-z0-9_]+/);
            if (match) {
                GatitoAndroid.onKeyFound(match[0]);
                return 'key_found';
            }

            // 2. Captcha Cloudflare?
            var captcha = document.querySelector(
                '.cf-turnstile, #cf-turnstile, [data-sitekey], ' +
                'iframe[src*="challenges.cloudflare"], iframe[src*="turnstile"], ' +
                'iframe[src*="hcaptcha"], .h-captcha'
            );
            if (captcha && captcha.offsetParent !== null) {
                GatitoAndroid.onCaptchaDetected();
                return 'captcha';
            }

            // 3. Timer aguardando?
            var timerSelectors = [
                '[id*="timer"]', '[class*="timer"]', '[id*="count"]',
                '[class*="countdown"]', '[class*="aguard"]'
            ];
            for (var ts = 0; ts < timerSelectors.length; ts++) {
                var timerEl = document.querySelector(timerSelectors[ts]);
                if (timerEl) {
                    var val = parseInt(timerEl.innerText || timerEl.textContent || '0');
                    if (val > 1) {
                        GatitoAndroid.onTimer(val);
                        return 'timer:' + val;
                    }
                }
            }

            // 4. Botões de continuar/ação (prioridade alta)
            var continueKeywords = ['continue aqui','clique para continuar','continuar','continue','prosseguir','acessar','avançar','get key','ir para'];
            var btns = document.querySelectorAll('a, button, [onclick], [class*="btn"], [class*="button"], [class*="link"]');
            for (var i = 0; i < btns.length; i++) {
                var el = btns[i];
                var t = (el.innerText || el.textContent || '').toLowerCase().trim();
                for (var k = 0; k < continueKeywords.length; k++) {
                    if (t.includes(continueKeywords[k]) && el.offsetParent !== null) {
                        el.click();
                        GatitoAndroid.onButtonClicked(t);
                        return 'clicked:' + t;
                    }
                }
            }

            // 5. Clique em anúncio (para liberar)
            var ads = document.querySelectorAll('a[href]');
            for (var j = 0; j < ads.length; j++) {
                var href = (ads[j].href || '').toLowerCase();
                var txt = (ads[j].innerText || ads[j].textContent || '').trim();
                if (href && href.startsWith('http') &&
                    !href.includes('submais') && !href.includes('paginadariqueza') &&
                    !href.includes('javascript') && !href.startsWith('#') &&
                    txt.length > 2 && ads[j].offsetParent !== null) {
                    ads[j].click();
                    GatitoAndroid.onAdClicked();
                    return 'ad_clicked';
                }
            }

            // 6. Ações sociais (Instagram/Telegram) - clica e volta
            var socialBtns = document.querySelectorAll('[href*="instagram"], [href*="t.me"], [href*="telegram"]');
            for (var s = 0; s < socialBtns.length; s++) {
                if (socialBtns[s].offsetParent !== null) {
                    socialBtns[s].click();
                    GatitoAndroid.onSocialClicked();
                    return 'social_clicked';
                }
            }

            return 'nothing';
        })();
        """.trimIndent()

        view.evaluateJavascript(js) { result ->
            val r = result?.replace("\"", "") ?: ""
            when {
                r == "nothing" || r == "no_body" ->
                    handler.postDelayed({ runBot(view) }, 3000)
                r.startsWith("timer:") -> { /* onTimer já agendou */ }
                r == "captcha" -> { /* onCaptchaDetected já chamado */ }
                r == "key_found" -> { /* onKeyFound já chamado */ }
            }
        }
    }

    private fun checkForKey(view: WebView) {
        view.evaluateJavascript("""
            (function(){
                var t = document.body ? (document.body.innerText || '') : '';
                var m = t.match(/King_Cheats_[A-Za-z0-9_]+/);
                return m ? m[0] : '';
            })();
        """) { result ->
            val key = result?.replace("\"", "")?.trim() ?: ""
            if (key.isNotEmpty() && key.length > 5) onKeyFound(key)
        }
    }

    // ─── BOTÕES ───────────────────────────────────────────────────────────────

    private fun setupButtons() {
        btnStart.setOnClickListener { startProcess() }
        btnStop.setOnClickListener { stopProcess() }
        btnCopy.setOnClickListener {
            val key = tvKey.text.toString()
            if (key.isNotEmpty()) {
                copyToClipboard(key)
                Toast.makeText(this, "Chave copiada! 🐾", Toast.LENGTH_SHORT).show()
            }
        }
        btnHistory.setOnClickListener {
            if (stateDone.visibility == View.VISIBLE || stateLoading.visibility == View.VISIBLE) return@setOnClickListener
            val showing = stateIdle.visibility == View.VISIBLE
            if (!showing) showState("idle")
            loadHistory()
        }
    }

    private fun startProcess() {
        isRunning = true
        stepCount = 0
        adClickCount = 0
        btnStart.isEnabled = false
        btnStop.isEnabled = true
        updateDots(0)
        showState("loading")
        tvLoadingMsg.text = loadingMessages[0]
        showNotification("Buscando chave... 🐾")
        startTimer()
        webView.loadUrl(TARGET_URL)
    }

    private fun stopProcess() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        stopTimer()
        btnStart.isEnabled = true
        btnStop.isEnabled = false
        showState("idle")
        cancelNotification()
        loadHistory()
    }

    private fun onKeyFound(key: String) {
        runOnUiThread {
            if (!isRunning) return@runOnUiThread
            isRunning = false
            handler.removeCallbacksAndMessages(null)
            stopTimer()
            saveKeyToHistory(key)
            tvKey.text = key
            tvKeyExpiry.text = "Válida por 24h · obtida em ${getCurrentTime()}"
            btnStart.isEnabled = true
            btnStop.isEnabled = false
            showState("done")
            copyToClipboard(key)
            cancelNotification()
            showNotification("😸 Chave: $key")
            Toast.makeText(this, "😸 Chave copiada: $key", Toast.LENGTH_LONG).show()
        }
    }

    // ─── HISTÓRICO ────────────────────────────────────────────────────────────

    private fun saveKeyToHistory(key: String) {
        val prefs = getSharedPreferences(PREFS_KEY, MODE_PRIVATE)
        val jsonStr = prefs.getString("keys", "[]") ?: "[]"
        val arr = try { JSONArray(jsonStr) } catch (e: Exception) { JSONArray() }

        // Remove entradas antigas (>24h)
        val now = System.currentTimeMillis()
        val filtered = JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val ts = obj.optLong("ts", 0)
            if (now - ts < 24 * 60 * 60 * 1000) filtered.put(obj)
        }

        val entry = JSONObject()
        entry.put("key", key)
        entry.put("ts", now)
        entry.put("time", getCurrentTime())
        filtered.put(entry)

        prefs.edit().putString("keys", filtered.toString()).apply()
    }

    private fun loadHistory() {
        val prefs = getSharedPreferences(PREFS_KEY, MODE_PRIVATE)
        val jsonStr = prefs.getString("keys", "[]") ?: "[]"
        val arr = try { JSONArray(jsonStr) } catch (e: Exception) { JSONArray() }

        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        var count = 0

        for (i in arr.length() - 1 downTo 0) {
            val obj = arr.getJSONObject(i)
            val ts = obj.optLong("ts", 0)
            if (now - ts < 24 * 60 * 60 * 1000) {
                val key = obj.optString("key", "")
                val time = obj.optString("time", "")
                val remaining = ((24 * 60 * 60 * 1000 - (now - ts)) / 60000).toInt()
                sb.append("🔑 $key\n   📅 $time · expira em ${remaining}min\n\n")
                count++
            }
        }

        tvHistory.text = if (count == 0) "Nenhuma chave encontrada ainda 🐾"
        else sb.toString().trim()
    }

    private fun getCurrentTime(): String {
        return SimpleDateFormat("HH:mm dd/MM", Locale.getDefault()).format(Date())
    }

    private fun copyToClipboard(text: String) {
        val cb = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cb.setPrimaryClip(android.content.ClipData.newPlainText("GatitoKey", text))
    }

    // ─── JS INTERFACE ─────────────────────────────────────────────────────────

    inner class JsInterface {

        @JavascriptInterface
        fun onKeyFound(key: String) = this@MainActivity.onKeyFound(key)

        @JavascriptInterface
        fun onCaptchaDetected() = runOnUiThread {
            showState("captcha")
            tvLoadingMsg.text = loadingMessages[2]
            showNotification("🛡️ Resolva o CAPTCHA!")
            Toast.makeText(this@MainActivity, "🛡️ Resolva o captcha para continuar!", Toast.LENGTH_LONG).show()
        }

        @JavascriptInterface
        fun onTimer(seconds: Int) = runOnUiThread {
            tvLoadingMsg.text = "⏳ Aguardando ${seconds}s..."
            // Contagem regressiva visual
            val countDown = object : Runnable {
                var remaining = seconds
                override fun run() {
                    if (!isRunning) return
                    if (remaining > 0) {
                        tvLoadingMsg.text = "⏳ Aguardando ${remaining}s..."
                        remaining--
                        handler.postDelayed(this, 1000)
                    } else {
                        tvLoadingMsg.text = "✅ Timer concluído! Clicando... 🐾"
                        handler.postDelayed({ if (isRunning) runBot(webView) }, 1500)
                    }
                }
            }
            handler.post(countDown)
        }

        @JavascriptInterface
        fun onButtonClicked(txt: String) = runOnUiThread {
            stepCount++
            updateDots(stepCount)
            tvLoadingMsg.text = loadingMessages[minOf(stepCount, loadingMessages.size - 1)]
            showNotification("Etapa $stepCount/$maxSteps 🐾")
        }

        @JavascriptInterface
        fun onAdClicked() = runOnUiThread {
            adClickCount++
            tvLoadingMsg.text = "Anúncio clicado ($adClickCount/$MAX_AD_CLICKS) → voltando... ↩️"

            // Volta após 1.5s
            handler.postDelayed({
                runOnUiThread {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    }
                    // Se não voltou sozinho, tenta de novo em 3s (máx 3 tentativas)
                    if (adClickCount < MAX_AD_CLICKS) {
                        handler.postDelayed({
                            if (isRunning) runBot(webView)
                        }, 3000)
                    }
                }
            }, 1500)
        }

        @JavascriptInterface
        fun onSocialClicked() = runOnUiThread {
            tvLoadingMsg.text = "Ação social feita → voltando... 🐾"
            handler.postDelayed({
                if (webView.canGoBack()) webView.goBack()
                handler.postDelayed({ if (isRunning) runBot(webView) }, 2000)
            }, 1500)
        }
    }
}
