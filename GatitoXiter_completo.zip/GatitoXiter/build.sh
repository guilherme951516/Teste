#!/bin/bash
# ══════════════════════════════════════════════
#  GATITO XITER - Setup + Build (Termux)
# ══════════════════════════════════════════════

PROJECT="/storage/emulated/0/Download/GatitoXiter"

echo "🐾 Copiando projeto..."
cp -r "$PROJECT"/* ~/GatitoXiter/ 2>/dev/null || true

echo "🔧 Configurando SDK..."
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

echo "sdk.dir=$HOME/android-sdk" > ~/GatitoXiter/local.properties

echo "🚀 Compilando..."
cd ~/GatitoXiter
chmod +x gradlew
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    APK="~/GatitoXiter/app/build/outputs/apk/debug/app-debug.apk"
    cp $APK /storage/emulated/0/Download/GatitoXiter.apk
    echo "✅ APK gerado em: /sdcard/Download/GatitoXiter.apk"
    echo "📱 Assine com MT Manager e instale!"
else
    echo "❌ Erro na compilação. Veja os logs acima."
fi
